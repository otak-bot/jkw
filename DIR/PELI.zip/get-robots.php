<?php

/**
 * Force Replace robots.txt
 */

$robotsFile = __DIR__ . '/robots.txt';

// Auto detect domain
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$domain = $protocol . '://' . $_SERVER['HTTP_HOST'];

// Isi robots.txt baru
$robotsContent = <<<TXT
User-agent: *
Allow: /

# Sitemap utama
Sitemap: {$domain}/site.xml

# Sitemap fairplay
Sitemap: {$domain}/fairplay/site.xml
TXT;

// Kalau robots.txt ada -> hapus
if (file_exists($robotsFile)) {
    unlink($robotsFile);
}

// Buat robots.txt baru
if (file_put_contents($robotsFile, $robotsContent)) {
    echo "robots.txt berhasil diperbarui";
} else {
    echo "Gagal membuat robots.txt";
}

?>