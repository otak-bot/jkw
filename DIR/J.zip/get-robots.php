<?php

/**
 * Force Replace robots.txt
 * Jika robots.txt sudah ada -> hapus lalu buat baru
 */

$robotsFile = __DIR__ . '/robots.txt';

// Auto detect domain
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$domain = $protocol . '://' . $_SERVER['HTTP_HOST'];

// Isi robots.txt baru
$robotsContent = <<<TXT
User-agent: *
Allow: /

# Block folder sensitif
Disallow: /admin/
Disallow: /private/
Disallow: /config/

# Sitemap
Sitemap: {$domain}/site.xml
TXT;

// Kalau robots.txt ada -> hapus
if (file_exists($robotsFile)) {
    unlink($robotsFile);
}

// Buat robots.txt baru
if (file_put_contents($robotsFile, $robotsContent)) {
    echo "robots.txt berhasil diperbarui";
} else {
    echo "Gagal membuat robots.txt";
}

?>